import {TodolistType} from "../App";
export type RemoveActionType = {
    type: 'REMOVE-TASK'
    taskId: string
    todolistId: string
}

type ActionType = FirstActionType | SecondActionType

export const taskReducer = (state: Array<TodolistType>, action: ActionType) => {
    switch (action.type) {
        case '':
            return state
        case '':
            return state
        default:
            return state
    }
}